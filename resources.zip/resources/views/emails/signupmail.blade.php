<!DOCTYPE html>
<html lang="en">
<head>

    <title>Lexenter</title>
</head>
<body>
<h1>{{ $details['title'] }}</h1>
<p>{{ $details['body'] }}</p>
<p>Thanks You!</p>
</body>
</html>
