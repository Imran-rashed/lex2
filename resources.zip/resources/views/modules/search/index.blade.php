@extends("layouts.app")

@section("title", "Lexenter")

@section("content")

    @include("partials.sidebar")
    @include("partials.header")
    <main class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                    	<div class="page-title">
                    		<h1>advance search</h1>
                    	</div>
                        <div class="search-box">
                            <select class="search-article-id">
                                <option></option>
                                <option>10000</option>
                                <option>22588</option>
                                <option>016556</option>
                            </select>
                            <select class="search-context-id">
                                <option></option>
                                <option>10000</option>
                                <option>22588</option>
                                <option>016556</option>
                            </select>
                            <select class="search-term">
                                <option></option>
                                <option>Hello</option>
                                <option>Yes</option>
                                <option>Hey</option>
                            </select>
                            <button type="submit">search</button>
                        </div>
                    </div>
                </div>
            </div>
        </main>
      <!-- page-content" -->
      
@endsection