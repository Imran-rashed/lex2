</div>
    <!-- page-wrapper -->
    <script src='js/jquery-3.4.1.min.js'></script>
    <script src='js/popper.js'></script>
    <script src='js/bootstrap.js'></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.tiny.cloud/1/qagffr3pkuv17a8on1afax661irst1hbr4e6tbv888sz91jc/tinymce/5.4.2-90/tinymce.min.js"></script>
    <script src="js/select2.min.js"></script>
    <script src="js/tagsinput.js"></script>
    <script src="js/script.js"></script>

</body>
</html>